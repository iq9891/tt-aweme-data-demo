App({
  globalData:{
    category:0
  },
  onLaunch: function () {
    const systemInfo = tt.getSystemInfoSync(); 
    this.setGlobalData('systemInfo',systemInfo);
  //   const requestTest = tt.requestOrderTest(); 
  //  console.log('requestTest',requestTest);
   const tts =tt.createOrder({
    goodsList: [
      {
        quantity: 10, // 购买数量 必填
        price: 1, // 商品价格 必填
  
        goodsName: "测试商品", // 商品名称 必填
        goodsPhoto:
          "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fpic.ibaotu.com%2Fgif%2F19%2F48%2F47%2F76Z888piCd6W.gif%21fwpaa50%2Ffw%2F700&refer=http%3A%2F%2Fpic.ibaotu.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1644654365&t=5fc9b5fdad0a16264a9a9c09c14b3af9", // 商品图片链接 必填
        goodsId: "123", // 商品ID 必填
        goodsType: 2, // 商品类型 必填
  
   
        dateRule: "", // 使用规则 非必填
      },
    ],
    payment: {
      totalAmount: 10, // 订单总价 必填
    },
    contactInfo: {
      phoneNumber: "12345678901", // 手机号 非必传
      contactName: "test name", // 姓名 非必传
    },
    note: "for future", // 备注 非必传
  
    storeInfo: {
      storeName: "test store", // 商店名称 非必传
      storeIcon:
        "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fpic.ibaotu.com%2Fgif%2F19%2F48%2F47%2F76Z888piCd6W.gif%21fwpaa50%2Ffw%2F700&refer=http%3A%2F%2Fpic.ibaotu.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1644654365&t=5fc9b5fdad0a16264a9a9c09c14b3af9", // 商店头像 非必填
    },
    callbackData: { test: 999999 }, // 透传数据，开发者自定义字段 非必传
    tradeOption:{
      life_trade_flag :0 // 0：非融合链路（默认值）  1：走融合链路（标准融合/完全融合）
    }, // 透传数据，开发者自定义字段 非必传
  
    success: (res) => {
      console.log(res);
      const { orderId, outOrderNo } = res;
      console.log("success res", res);
      console.log("orderId", orderId, "outOrderNo", outOrderNo);
      this.setData({ orderId, outOrderNo });
    },
    fail: (res) => {
      const { orderId, outOrderNo, errNo, errMsg, errLogId } = res;
      if (errLogId) {
        console.log("预下单失败", errNo, errMsg, errLogId);
      }
      if (orderId || outOrderNo) {
        console.log("支付失败", errNo, errMsg, orderId, outOrderNo);
      }
      console.log(errNo, errMsg);
    },
  });
  console.log('tts',tts);

  
  },
  getPhoneNumber({ params, success, fail }) {
    const { iv, encryptedData } = params;
    // ...
    // 开发者服务端解密 encryptedData，得到手机号
    // ...
    const result = {
        phoneNumber: '18133842224',
    }
    // 回调前端模板
    success(result)
},
setGlobalData(key, value) {
  this.globalData[key] = value;
},
})
