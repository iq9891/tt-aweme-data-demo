// /Users/bytedance/Desktop/test_副本/pages/index/applyrefund/applyrefund.js
Page({
  data: {

  },
  // bind:refund 使用示例 
handleRefund(event) { 
  console.log('event',event);
  const { status, result } = event.detail; 
  if (status === 'success') { 
      const { refundId, outRefundNo } = result; 
  } else { 
      const { errMsg } = result; 
  } 
},
// bind:applyrefund 使用示例 
applyRefund(event) { 
  console.log('event',event);
  const { orderId } = event.detail; 
  const extra = { orderId }; // 开发者需要透传的参数，可自定义内容 
  return new Promise(resolve => { 
    resolve(extra); 
  }); 
}, 
errorHandler(event){
  const { errNo , errMsg } = event.detail
  // do something
  // errNo（错误码，对应某种具体报错原因）
  // errMsg（报错信息）
},
  onLoad: function (options) {

  }
})